library(sandwich)
library(dplyr)
library(readxl)

# Libraries for the mapping
library(maps)
library(ggplot2)
library(broom)
library(ggmap)
library(ggforce)

## Calculate distances
library(geosphere)

## Plot marginal effect
library(marginaleffects)


quepro <- readRDS(file = "PATH QUEPRO FILE") 

quepro <- quepro %>% select(id, region, mil_det, mil_ali, trust1, trust3, trust1_dummy, trust3_dummy, threat2, treatment_lvl)


## Code East column
east_regions = c(4, 8, 13, 14, 16)

quepro <- quepro %>% mutate(east =
                              ifelse(region %in% east_regions, 1, 0))

quepro$east <- factor(quepro$east, levels = 0:1, labels = c("West", "East"))

## Regions:

region_labels <- c(
  "Baden-Württemberg", "Bayern", "Berlin", "Brandenburg", "Bremen", "Hamburg",
  "Hessen", "Mecklenburg-Vorpommern", "Niedersachsen", "Nordrhein-Westfalen", 
  "Rheinland-Pfalz", "Saarland", "Sachsen", "Sachsen-Anhalt", 
  "Schleswig-Holstein", "Thüringen"
)

# Replace the region numbers with the corresponding names
quepro$region <- factor(quepro$region, levels = 1:16, labels = region_labels)



# BELIEVE IN DETERRENCE

## East/West Dummy

# Calculate the mean and standard error of mil_det for east/west

average_mil_det_east <- quepro %>%
  group_by(east) %>%
  summarise(
    mil_det_mean = mean(mil_det),
    mil_det_se = sd(mil_det) / sqrt(n())  
  )

# Add confidence intervals (95%)
average_mil_det_east <- average_mil_det_east %>%
  mutate(
    ci_lower = mil_det_mean - 1.96 * mil_det_se,
    ci_upper = mil_det_mean + 1.96 * mil_det_se
  )

# Plot
ggplot(average_mil_det_east, aes(x = east, y = mil_det_mean, fill=east)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper), width = 0.2) +
  labs(
    title = "Q: A strong military... provokes conflict (0) - ...guarantees peace (100)",
    x = "West (incl. Berlin) vs East",  
    y = "Average Score"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8), 
    plot.title = element_text(hjust = 0.5),
    legend.title = element_blank()
  )  + scale_fill_manual(values = c("West" = "steelblue", "East" = "darkorange"))  




# BELIEVE IN ALLIANCES

## East/West Dummy

average_mil_ali_east <- quepro %>%
  group_by(east) %>%
  summarise(
    mil_det_mean = mean(mil_ali),
    mil_det_se = sd(mil_ali) / sqrt(n())  
  )

# Add confidence intervals (95%)
average_mil_ali_east <- average_mil_ali_east %>%
  mutate(
    ci_lower = mil_det_mean - 1.96 * mil_det_se,
    ci_upper = mil_det_mean + 1.96 * mil_det_se
  )

# Plot
ggplot(average_mil_ali_east, aes(x = east, y = mil_det_mean, fill = east)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper), width = 0.2) +
  labs(
    title = "Q: Germany can rely on allies... not at all (0) - ...completely (100)",
    x = "West (incl. Berlin) vs East",  
    y = "Average Score"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8), 
    plot.title = element_text(hjust = 0.5),
    legend.title = element_blank()
  )  + scale_fill_manual(values = c("West" = "steelblue", "East" = "darkorange"))  


# Trust US


# Calculate the percentage of 1's in trust_dummy_1 per region
average_trust_dummy_east <- quepro %>%
  group_by(east) %>%
  summarise(
    trust_dummy_mean = mean(trust1_dummy) * 100,  
    trust_dummy_se = (sd(trust1_dummy) / sqrt(n())) * 100  
  )

# Add confidence intervals (95%)
average_trust_dummy_east <- average_trust_dummy_east %>%
  mutate(
    ci_lower = trust_dummy_mean - 1.96 * trust_dummy_se,
    ci_upper = trust_dummy_mean + 1.96 * trust_dummy_se
  )

# Plot
ggplot(average_trust_dummy_east, aes(x = east, y = trust_dummy_mean, fill = east)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper), width = 0.2) +
  labs(
    title = "Q: Do you trust the US?",
    x = "West (incl. Berlin) vs East",  
    y = "Percentage Yes"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8), 
    plot.title = element_text(hjust = 0.5),
    legend.title = element_blank()
  )  + scale_fill_manual(values = c("West" = "steelblue", "East" = "darkorange"))  


# Trust Russia


# Calculate the percentage of 1's in trust_dummy_3 per region
average_trust_dummy_east <- quepro %>%
  group_by(east) %>%
  summarise(
    trust_dummy_mean = mean(trust3_dummy) * 100,  
    trust_dummy_se = (sd(trust3_dummy) / sqrt(n())) * 100  
  )

# Add confidence intervals (95%)
average_trust_dummy_east <- average_trust_dummy_east %>%
  mutate(
    ci_lower = trust_dummy_mean - 1.96 * trust_dummy_se,
    ci_upper = trust_dummy_mean + 1.96 * trust_dummy_se
  )

# Plot
ggplot(average_trust_dummy_east, aes(x = east, y = trust_dummy_mean, fill = east)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper), width = 0.2) +
  labs(
    title = "Q: Do you trust Russia?",
    x = "West (incl. Berlin) vs East",  
    y = "Percentage Yes"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8), 
    plot.title = element_text(hjust = 0.5),
    legend.title = element_blank()
  )  + scale_fill_manual(values = c("West" = "steelblue", "East" = "darkorange"))  



# Threat: War involving my country

## Create dummy: Threat < 4 == not likely
quepro <- quepro %>% 
  mutate(threat_entrap =
           ifelse(threat2 < 4, 0, 1)
           )

# Calculate the percentage of 1's per region: Just for baseline scenario in experiment, not treatment groups 1-3
average_trust_dummy_east <- quepro %>%
  filter(treatment_lvl==0) %>%
  group_by(east) %>%
  summarise(
    trust_dummy_mean = mean(threat_entrap, na.rm=T) * 100,  
    trust_dummy_se = (sd(threat_entrap, na.rm=T) / sqrt(n())) * 100  
  )

# Add confidence intervals (95%)
average_trust_dummy_east <- average_trust_dummy_east %>%
  mutate(
    ci_lower = trust_dummy_mean - 1.96 * trust_dummy_se,
    ci_upper = trust_dummy_mean + 1.96 * trust_dummy_se
  )

# Plot
ggplot(average_trust_dummy_east, aes(x = east, y = trust_dummy_mean, fill = east)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper), width = 0.2) +
  labs(
    title = "Q: Will Germany be entrapped in a US-Russia war?",
    x = "West (incl. Berlin) vs East",  
    y = "Percentage Yes"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8), 
    plot.title = element_text(hjust = 0.5),
    legend.title = element_blank()
  )  + scale_fill_manual(values = c("West" = "steelblue", "East" = "darkorange"))  





# MAPPING

## Create German map
world_map <- map("world", fill = TRUE, plot = FALSE)

world_map_df <- tidy(world_map)

world_map_df <- world_map_df[world_map_df$region == "Germany",]

# register_google("API KEY")
# 
# quepro_postcode <- quepro %>% filter(!is.na(postal_code))
# 
# quepro_postcode$postal_code <- as.character(quepro_postcode$postal_code)
# 
# quepro_postcode$lat_lon <- geocode(quepro_postcode$postal_code)
# 
# quepro_postcode <- quepro_postcode %>%
#   unnest(lat_lon)
# 
# quepro_postcode <- quepro_postcode %>% select(id, lon, lat, trust1)

## German cities with > 250,000 inhabitants
cities_data <- data.frame(
  city = c("Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf", "Dortmund", "Essen", "Leipzig"),
  latitude = c(52.52, 53.55, 48.13, 50.94, 50.11, 48.78, 51.23, 51.51, 51.46, 51.34),
  longitude = c(13.405, 9.993, 11.582, 6.957, 8.682, 9.181, 6.774, 7.466, 7.012, 12.38)
)

## Add US bases in Germany list

us_bases <- read_excel("PATH US BASES FILE")

## Add long/lat postal code data

quepro_postcode <- readRDS(file="PATH QUEPRO POSTCODE FILE")

quepro_postcode$trust1_cat <- factor(quepro_postcode$trust1, 
                                     levels = 1:4, 
                                     labels = c("Not at all", "Rather not", "Somewhat", "A lot"))

ggplot() +
  geom_polygon(data = world_map_df, aes(x = long, y = lat, group = group), 
               fill = "lightgray", color = "black") +
  
  geom_point(data = quepro_postcode, aes(x = lon, y = lat, color = trust1_cat), 
             alpha = 0.5, size = 2) +  
  
  geom_point(data = cities_data, aes(x = longitude, y = latitude), color = "blue", size = 3) +
  
  geom_text(data = cities_data, aes(x = longitude, y = latitude, label = city), 
            vjust = -1, hjust = 0.5, size = 3, color = "black") +
  
  geom_point(data = us_bases, aes(x = long, y = lat, shape = "US Military Base"), 
             color = "black", size = 4) +  
  
  labs(
    title = "Q: To what extend do you trust the US?",
    x = "", y = "", color = "Trust in US", shape = "Symbol"
  ) +
  
  coord_fixed(1.3) +
  
  theme_minimal() +
  
  theme(
    axis.title.x = element_blank(), 
    axis.title.y = element_blank(),
    axis.text.x = element_blank(), 
    axis.text.y = element_blank(),
    axis.ticks = element_blank(),
  ) +
  
  
  scale_color_manual(values = c("Not at all" = "red", 
                                "Rather not" = "orange", 
                                "Somewhat" = "yellow", 
                                "A lot" = "green")) +

  
  scale_shape_manual(values = c("US Military Base" = 4)) +  
  
  guides(shape = guide_legend(override.aes = list(color = "black", size = 4)))




## Regression: Distance to military base

quepro_distance <- quepro_postcode %>% select(id, lon, lat)


## Add each long, lat of us bases as a column
for (i in 1:nrow(us_bases)) {
  quepro_distance[[paste0("long_base", i)]] <- us_bases$long[i]
  quepro_distance[[paste0("lat_base", i)]] <- us_bases$lat[i]
}


## Add a column for distance of each respondent with each base
for(i in 1:13) {
  for (j in 1:nrow(quepro_distance)) {
    quepro_distance[j, paste0("distance", i)] <- distHaversine(
      c(as.vector(quepro_distance[j,"lon"], mode="numeric"), as.vector(quepro_distance[j, "lat"], mode="numeric")), 
      c(as.vector(quepro_distance[j, paste0("long_base",i)], mode="numeric"), as.vector(quepro_distance[j, paste0("lat_base",i)], mode="numeric"))
  )
                                                    
  }
}

## Find the closest base per respondent

quepro_distance <- quepro_distance %>%
  rowwise() %>%  
  mutate(min_distance = min(c_across(starts_with("distance")), na.rm = TRUE)) %>%  
  ungroup()  

## Transform into km

quepro_distance$min_distance <- quepro_distance$min_distance/1000

## Create dummy: Within 100 km of base y/n
quepro_distance$dist60 <- 0
quepro_distance$dist60[quepro_distance$min_distance<=60] <- 1

## Add to original dataframe

quepro_distance <- quepro_distance %>% select(id, min_distance, dist60) %>% filter(!is.na(id))

quepro <- left_join(quepro, quepro_distance, by="id")

## Run regression

## no controls to ensure anonymity of respondents
model1 <- glm(trust1_dummy ~ dist60 + east, data=quepro, family = binomial)

p <- plot_predictions(model1, condition = "dist60", type = "response", 
                      vcov = "HC3", conf_level = 0.90)

# Customize the plot
p + 
  theme_minimal(base_size = 15) +                      
  labs(title = "Predicted Probability: Distance < 60 KM",
       subtitle = "90% Confidence Intervals",
       x = "",
       y = "") +           
  scale_x_discrete(breaks = c(0, 1),                    
                   labels = c(">60", "<60")) + 
  theme(plot.title = element_text(face = "bold",        
                                  hjust = 0.5),          
        plot.subtitle = element_text(hjust = 0.5),
        axis.title.x = element_text(margin = margin(t = 10)), 
        axis.title.y = element_text(margin = margin(r = 10))) + 
  geom_point(size = 3, color = "darkblue") +            
  geom_errorbar(width = 0.2, color = "black")       


## Run regression: Continuous distance varibale

## no controls to ensure anonymity of respondents

model2 <- glm(trust1_dummy ~ min_distance + east, data=quepro, family = binomial)

p <- plot_predictions(model2, condition = "min_distance", type = "response", 
                      vcov = "HC3", conf_level = 0.90)

# Customize the plot
p + 
  theme_minimal(base_size = 15) +                      
  labs(title = "Predicted Probability: Distance (continuous)",
       subtitle = "90% Confidence Intervals",
       x = "",
       y = "") +           
  scale_x_discrete(breaks = c(0, 1),                    
                   labels = c(">60", "<60")) + 
  theme(plot.title = element_text(face = "bold",        
                                  hjust = 0.5),          
        plot.subtitle = element_text(hjust = 0.5),
        axis.title.x = element_text(margin = margin(t = 10)), 
        axis.title.y = element_text(margin = margin(r = 10))) + 
  geom_point(size = 3, color = "darkblue") +            
  geom_errorbar(width = 0.2, color = "black")           














# ggplot() +
#   geom_polygon(data = world_map_df, aes(x = long, y = lat, group = group),
#                fill = "lightgray", color = "black") +
# 
#   geom_point(data = cities_data, aes(x = longitude, y = latitude), color = "blue", size = 3) +
# 
#   geom_text(data = cities_data, aes(x = longitude, y = latitude, label = city),
#             vjust = -1, hjust = 0.5, size = 3, color = "black") +
# 
#   geom_point(data = us_bases, aes(x = long, y = lat, shape = "US Military Base"),
#              color = "black", size = 4) +
# 
#   labs(
#     title = "",
#     x = "", y = "", shape = "Symbol"
#   ) +
# 
#   coord_fixed(1.3) +
# 
#   theme_minimal() +
# 
#   theme(
#     axis.title.x = element_blank(),
#     axis.title.y = element_blank(),
#     axis.text.x = element_blank(),
#     axis.text.y = element_blank(),
#     axis.ticks = element_blank(),
#   ) +
# 
#   scale_shape_manual(values = c("US Military Base" = 4)) +
# 
#   guides(shape = guide_legend(override.aes = list(color = "black", size = 4)))
# 
